document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que se envíe el formulario de forma tradicional
    alert('Formulario de inicio de sesión enviado.');
});

document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que se envíe el formulario de forma tradicional
    alert('Formulario de registro enviado. (Este es un mensaje de simulación)');
});

function showRegister() {
    document.getElementById('loginForm').parentElement.style.display = 'none';
    document.getElementById('registerContainer').style.display = 'block';
}

function showLogin() {
    document.getElementById('registerContainer').style.display = 'none';
    document.getElementById('loginForm').parentElement.style.display = 'block';
}
